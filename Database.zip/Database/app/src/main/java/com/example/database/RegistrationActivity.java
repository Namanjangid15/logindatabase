package com.example.database;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegistrationActivity extends AppCompatActivity {

    private EditText uName, uPassword , uEmail;
    private Button regbtn;
    private TextView uLogin;
    private FirebaseAuth firebaseAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setupUIViews();

        firebaseAuth = FirebaseAuth.getInstance();

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    ////// upload data to database
                    String user_email = uEmail.getText().toString().trim();
                    String user_password = uPassword.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email,user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                Toast.makeText(RegistrationActivity.this, "registration successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(RegistrationActivity.this,MainActivity.class));
                            }else{
                                Toast.makeText(RegistrationActivity.this, "registration Fail", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        uLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this,MainActivity.class));

            }
        });
    }

    private Boolean validate() {
        Boolean result = false;

        String name = uName.getText().toString();
        String  pass = uPassword.getText().toString();
        String email = uEmail.getText().toString();

        if (name.isEmpty() && pass.isEmpty() && email.isEmpty()){
            Toast.makeText(this,"Enter all the details",Toast.LENGTH_SHORT).show();
        }else {
            result = true;

        }
        return result;
    }

    private void setupUIViews(){
        uName = (EditText)findViewById(R.id.etUserName);
        uPassword = (EditText)findViewById(R.id.etPassword);
        uEmail = (EditText)findViewById(R.id.etUserEmail);
        regbtn = (Button)findViewById(R.id.btnRegister);
        uLogin = (TextView)findViewById(R.id.registerlogin);
    }
}
